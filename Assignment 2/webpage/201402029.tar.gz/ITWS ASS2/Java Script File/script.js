function mybrowser()
{
document.getElementById("brow").innerHTML=
"Name is " + navigator.appName + "<br>Code Name is " + navigator.appCodeName;
}
function path()
{
var x=location.pathname;
document.getElementById("path").innerHTML= x;
}
function time()
{
document.getElementById("demo").innerHTML=time();
}
